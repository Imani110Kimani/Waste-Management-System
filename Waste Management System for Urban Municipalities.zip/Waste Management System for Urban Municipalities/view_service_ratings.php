<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "waste management system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// SQL query to retrieve feedback
$sql = "SELECT id, rating, feedback FROM service_ratings";
$result = $conn->query($sql);

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Feedback</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .feedback-table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .feedback-table th, .feedback-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        .feedback-table th {
            background-color: #2980b9;
            color: white;
        }
        .feedback-table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .feedback-table tr:hover {
            background-color: #e0e0e0;
        }
        .button-container {
            margin-top: 20px;
        }
        .return-button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #2980b9;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .return-button:hover {
            background-color: #1c598a;
        }
    </style>
</head>
<body>
    <div class="feedback-container">
        <h2>Feedback</h2>
        <?php
        if ($result->num_rows > 0) {
            echo "<table class='feedback-table'>
                    <tr>
                        <th>ID</th>
                        <th>Rating</th>
                        <th>Feedback</th>
                    </tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row["id"] . "</td>
                        <td>" . $row["rating"] . "</td>
                        <td>" . $row["feedback"] . "</td>
                    </tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No feedback found.</p>";
        }
        ?>
    </div>
    <div class="button-container">
        <button class="return-button" onclick="window.location.href='admin_dashboard.php'">Return to Dashboard</button>
    </div>
</body>
</html>
