<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "waste management system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user ID from session
$user_id = $_SESSION['user_id'];

// Validate and sanitize request ID
$request_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Prepare SQL statement to retrieve specific service request details
$sql = "SELECT * FROM service_requests WHERE request_id = ? AND id = ?";
$stmt = $conn->prepare($sql);

if ($stmt) {
    // Bind parameters and execute statement
    $stmt->bind_param("ii", $request_id, $user_id);
    $stmt->execute();

    // Get result
    $result = $stmt->get_result();

    // Check if there is exactly one row returned
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        // Process the service request as needed
        // For example, update the status, notify the user, etc.
        // Here we'll just display the details
        echo '<h2>Service Request Details</h2>';
        echo '<p><strong>Request ID:</strong> ' . $row['request_id'] . '</p>';
        echo '<p><strong>County:</strong> ' . $row['county'] . '</p>';
        echo '<p><strong>Constituency:</strong> ' . $row['constituency'] . '</p>';
        echo '<p><strong>Phone:</strong> ' . $row['phone'] . '</p>';
        echo '<p><strong>Services:</strong> ' . $row['services'] . '</p>';
        echo '<p><strong>Status:</strong> ' . $row['status'] . '</p>';
    } else {
        echo '<p>No service request found for the provided ID.</p>';
    }

    // Close statement
    $stmt->close();
} else {
    echo '<p>Error retrieving service request details.</p>';
}

// Close connection
$conn->close();
?>
