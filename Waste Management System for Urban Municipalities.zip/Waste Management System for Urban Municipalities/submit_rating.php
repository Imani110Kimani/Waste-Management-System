<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "waste management system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("User session not found. Please log in.");
}

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Validate and sanitize inputs
$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0; // Assuming rating is an integer
$feedback = isset($_POST['feedback']) ? $conn->real_escape_string($_POST['feedback']) : '';

// Prepare SQL statement using a prepared statement to prevent SQL injection
$sql = "INSERT INTO service_ratings (id, rating, feedback) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt) {
    // Bind parameters and execute the statement
    $stmt->bind_param("iis", $id, $rating, $feedback);

    if ($stmt->execute()) {
        echo "<script>alert('Thank you for your feedback!'); window.location.href='dashboard.php';</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "'); window.location.href='index.html';</script>";
    }

    // Close statement
    $stmt->close();
} else {
    echo "<script>alert('Error preparing statement: " . $conn->error . "'); window.location.href='index.html';</script>";
}

// Close connection
$conn->close();
?>
