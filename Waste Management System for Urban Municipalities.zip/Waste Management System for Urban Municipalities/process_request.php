<?php
// Database configuration
$servername = "localhost";
$username = "root"; // Use your database username
$password = ""; // Use your database password
$dbname = "your_database_name"; // Use your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $service_type = $_POST['service_type'];
    $service_date = $_POST['service_date'];
    $details = $_POST['details'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO service_requests (service_type, service_date, details) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $service_type, $service_date, $details);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Service request submitted successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
