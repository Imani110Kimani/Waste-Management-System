<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "waste management system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Retrieve number of requests
$sql = "SELECT COUNT(*) AS request_count FROM service_requests";
$result = $conn->query($sql);

if ($result) {
    // Fetch the result as an associative array
    $row = $result->fetch_assoc();
    $request_count = $row['request_count'];

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode(['request_count' => $request_count]);
} else {
    // Return JSON response with error
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Error fetching request count']);
}

// Close connection
$conn->close();
?>
