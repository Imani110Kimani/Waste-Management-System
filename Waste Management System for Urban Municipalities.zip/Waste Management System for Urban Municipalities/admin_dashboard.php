<?php
session_start();

$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "waste management system";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['schedule_service'])) {
    $service_date = $_POST['service_date'];
    $service_time = $_POST['service_time'];
    $location = $_POST['location'];

    $schedule_sql = "INSERT INTO scheduled_services (service_date, service_time, location) VALUES ('$service_date', '$service_time', '$location')";

    if ($conn->query($schedule_sql) === TRUE) {
        echo "<script>alert('Service scheduled successfully');</script>";
    } else {
        echo "<script>alert('Error scheduling service: " . $conn->error . "');</script>";
    }
}

$scheduled_services_sql = "SELECT id, service_date, service_time, location FROM scheduled_services ORDER BY service_date, service_time";
$scheduled_services_result = $conn->query($scheduled_services_sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Waste Management Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            display: flex;
            height: 100vh;
        }
        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: #ecf0f1;
            height: 100%;
            padding: 20px;
            overflow-y: auto;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 15px 0;
        }
        .sidebar ul li a {
            color: #ecf0f1;
            text-decoration: none;
        }
        .main-content {
            flex-grow: 1;
            padding: 20px;
            overflow-y: auto;
        }
        .header {
            background-color: #2980b9;
            color: white;
            padding: 20px;
            text-align: center;
            margin-bottom: 20px;
        }
        .header h1 {
            margin: 0;
        }
        .header p {
            margin: 5px 0 0 0;
        }
        .content {
            display: none;
        }
        .content h2 {
            margin-top: 0;
        }
        .stats {
            display: flex;
            justify-content: space-around;
            margin-bottom: 20px;
        }
        .stat-box {
            background-color: #ecf0f1;
            padding: 20px;
            width: 22%;
            text-align: center;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #2980b9;
            color: white;
        }
        form {
            background-color: #ecf0f1;
            padding: 20px;
            border-radius: 5px;
            max-width: 600px;
            margin: 20px auto;
        }
        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        form input[type="text"],
        form input[type="date"],
        form input[type="time"],
        form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        form button {
            background-color: #2980b9;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        form button:hover {
            background-color: #21618c;
        }
        #chart-container {
            width: 100%;
            max-width: 600px;
            margin: 20px auto;
        }
        #map {
            height: 500px;
            width: 100%;
        
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #2980b9;
            color: white;
        }
        .button {
            background-color: #2980b9;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            display: inline-block;
        }
        .button:hover {
            background-color: #21618c;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
            border-radius: 5px;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        /* Styles for the popup form */
        .popup-form {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            z-index: 1000;
            border-radius: 10px;
        }
        .popup-form input {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .popup-form button {
            padding: 10px 20px;
            background-color: #2980b9;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .popup-form button:hover {
            background-color: #1c598a;
        }
        .close-button {
            background-color: #e74c3c;
        }
        .close-button:hover {
            background-color: #c0392b;
        }
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 999;
        }
        .button-container {
            margin-top: 20px;
        }
        .return-button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #2980b9;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .return-button:hover {
            background-color: #1c598a;
        }
    </style>
    <script>
        function showSection(sectionId) {
            var contents = document.querySelectorAll('.content');
            contents.forEach(content => content.style.display = 'none');
            var selectedContent = document.getElementById(sectionId);
            selectedContent.style.display = 'block';
        }

        document.addEventListener('DOMContentLoaded', () => {
            showSection('dashboard');
        });
    </script>
</head>
<body>
    <div class="sidebar">
        <h2>Admin Dashboard</h2>
        <ul>
            <li><a href="#dashboard" onclick="showSection('dashboard')">Dashboard</a></li>
            <li><a href="#manage_users" onclick="showSection('manage_users')">Manage Users</a></li>
            <li><a href="#collection" onclick="showSection('collection')">Waste Collection</a></li>
            <li><a href="#schedule_service" onclick="showSection('schedule_service')">Schedule Service</a></li>
            <li><a href="view_service_ratings.php" onclick="showSection('feedback')">View Feedback</a></li>
            <li><a href="view_reports.php" onclick="showSection('incidents')">View Incidents</a></li>
            <li><a href="view_service_request.php" onclick="showSection('incidents')">View Service Request</a></li>
        </ul>
    </div>
    <div class="main-content">
        <div class="header">
            <?php
            // Display admin dashboard content
            echo "<h1>Welcome, " . htmlspecialchars($_SESSION['admin_email']) . "</h1>";
            ?>
            <p>Waste Management System</p>
        </div>
        <div class="content" id="dashboard" style="display: block;">
            <h2>Dashboard</h2>
            <div class="stats">
                <div class="stat-box">
                    <h3>Total Users</h3>
                    <p id="total-users"></p>
                </div>
                <div class="stat-box">
                    <h3>Collection Requests</h3>
                    <p id="collection-requests"></p>
                </div>
                <div class="stat-box">
                    <h3>Completed Collections</h3>
                    <p id="completed-collections"></p>
                </div>
                <div class="stat-box">
                    <h3>Reported Incidents</h3>
                    <p id="reported-incidents"></p>
                </div>
            </div>
            <div id="chart-container">
                <canvas id="feedback-chart"></canvas>
            </div>
        </div>
        <div class="content" id="manage_users">
            <h2>Manage Users</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="user-table">
                    <?php
                    $sql = "SELECT id, Fullname, email FROM users";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<tr>';
                            echo '<td>' . $row['id'] . '</td>';
                            echo '<td>' . $row['Fullname'] . '</td>';
                            echo '<td>' . $row['email'] . '</td>';
                            echo '<td><button onclick="editUser(' . $row['id'] . ')">Edit</button></td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="4">No users found</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div class="button-container">
        <button class="return-button" onclick="window.location.href='admin_dashboard.php'">Return to Dashboard</button>
    </div>
    
    <!-- Overlay for popup -->
    <div class="overlay" id="overlay"></div>

    <!-- Popup form for editing user -->
    <div class="popup-form" id="editForm">
        <h3>Edit User</h3>
        <form id="editUserForm" method="POST" action="edit_user.php">
            <input type="hidden" id="editUserId" name="id">
            <label for="editFullname">Fullname:</label>
            <input type="text" id="editFullname" name="fullname" required>
            <label for="editEmail">Email:</label>
            <input type="email" id="editEmail" name="email" required>
            <button type="submit">Save Changes</button>
            <button type="button" class="close-button" onclick="closeEditForm()">Cancel</button>
        </form>
    </div>

    <script>
        function editUser(id, fullname, email) {
            document.getElementById('editUserId').value = id;
            document.getElementById('editFullname').value = fullname;
            document.getElementById('editEmail').value = email;
            document.getElementById('editForm').style.display = 'block';
            document.getElementById('overlay').style.display = 'block';
        }

        function closeEditForm() {
            document.getElementById('editForm').style.display = 'none';
            document.getElementById('overlay').style.display = 'none';
        }
    </script>
   <!-- In your admin_dashboard.php or HTML structure -->

<div class="content" id="collection">
    <h2>Waste Collection</h2>
    <!-- Button to open waste collection pop-up -->
    <button class="button" onclick="openCollectionPopup()">Open Waste Collection</button>
</div>

<!-- Modal for Waste Collection -->
<div id="collection-modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeCollectionPopup()">&times;</span>
        <h2>Waste Collection</h2>
        
        <!-- Overview of collection requests -->
        <div class="stats">
        <div class="stat-box">
    <h3>Total Requests</h3>
    <p id="total-requests"></p>
    <p><a href="admin_dashboard.php">Back to Dashboard</a></p>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // AJAX request to fetch request count
        $.ajax({
            url: 'get_request_count.php', // Replace with the path to your PHP script
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.request_count !== undefined) {
                    $('#total-requests').text('Total number of service requests made by all users: ' + response.request_count);
                } else {
                    $('#total-requests').text('Error fetching request count');
                }
            },
            error: function() {
                $('#total-requests').text('Error fetching request count');
            }
        });
    });
</script>

            <div class="stat-box">
                <h3>Completed Requests</h3>
                <p id="completed-requests"></p>
            </div>
            <div class="stat-box">
                <h3>Pending Requests</h3>
                <p id="pending-requests"></p>
            </div>
        </div>
        
        <!-- Real-time monitoring and map -->
        <div id="collection-map"></div>
        
        <!-- Collection schedule management -->
        <h2>Manage Collection Schedules</h2>
        <table>
            <thead>
                <tr>
                    <th>Route Name</th>
                    <th>Frequency</th>
                    <th>Last Collection</th>
                    <th>Next Collection</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="collection-schedule-table">
                <!-- Populate collection schedule data dynamically -->
            </tbody>
        </table>
        
        <!-- Reporting and analytics -->
        <h2>Analytics and Reporting</h2>
        <div id="collection-analytics">
            <!-- Charts and graphs displaying collection data -->
        </div>
        
        <!-- Notification and alerts -->
        <h2>Notifications</h2>
        <div id="collection-notifications">
            <!-- Display notifications and alerts -->
        </div>
    </div>
</div>

<script>
            function openCollectionPopup() {
                document.getElementById('collection-modal').style.display = 'block';
            }
            
            function closeCollectionPopup() {
                document.getElementById('collection-modal').style.display = 'none';
            }
        </script>
        <div class="content" id="post_event">
            <h2>Post Events</h2>
            <form method="POST" action="post_event.php">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" required><br>
                <label for="description">Description:</label>
                <textarea id="description" name="description" required></textarea><br>
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" required><br>
                <label for="time">Time:</label>
                <input type="time" id="time" name="time" required><br>
                <label for="location">Location:</label>
                <input type="text" id="location" name="location" required><br>
                <button type="submit">Post Event</button>
            </form>
        </div>
        <div class="content" id="schedule_service">
    <h2>Schedule Service</h2>
    <button class="button" onclick="document.getElementById('modal').style.display='block'">Schedule New Service</button>

    <div id="modal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="document.getElementById('modal').style.display='none'">&times;</span>
        
                <form action="schedule_service.php" method="POST">
                <label for="service_date">Service Date:</label>
                <input type="date" id="service_date" name="service_date" required>
                <label for="service_time">Service Time:</label>
                <input type="time" id="service_time" name="service_time" required>
                <label for="location">Location:</label>
                <input type="text" id="location" name="location" required>
                <button type="submit" name="schedule_service">Schedule Service</button>
            </form>
        </div>
</div>
<?php
// Database connection details
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "waste management system";

// Create the connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve all scheduled services
$sql = "SELECT * FROM schedule_services";
$result = $conn->query($sql);
$admin_id =$_SESSION['admin_id']; // Get the admin ID from the session
// Close the connection
$conn->close();
?>
<div>
<h2>Scheduled Services</h2>
    
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Service Date</th>
                <th>Service Time</th>
                <th>Location</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>" . htmlspecialchars($row['id']) . "</td>
                        <td>" . htmlspecialchars($row['service_date']) . "</td>
                        <td>" . htmlspecialchars($row['service_time']) . "</td>
                        <td>" . htmlspecialchars($row['location']) . "</td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No scheduled services found</td></tr>";
            }
            ?>
        </tbody>
    </table>
       
</div>

        <div class="content" id="feedback">
            <h2>View Feedback</h2>
        </div>
        </div>
        <div class="content" id="incidents">
            <h2>View Incidents</h2>
        </div>
        <div class="content" id="gps">
            <h2>GPS Map</h2>
            <div id="map"></div>
        </div>
        
        

<script>
function openPopup(requestId) {
    // Open popup window for processing request
    var popupUrl = 'process_request.php?id=' + requestId;
    var popupWindow = window.open(popupUrl, '_blank', 'width=600,height=400');
    if (!popupWindow) {
        alert('Popup blocked! Please allow popups for this site.');
    }
}
</script>

        </div>
    </div>
   
</body>
</html>


        
