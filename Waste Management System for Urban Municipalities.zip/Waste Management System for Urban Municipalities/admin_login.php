<?php
session_start(); // Start the session

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection parameters
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "waste management system"; // Corrected database name with underscores

// Create connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables for form data
$email = '';
$password = '';
$error_message = '';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Debugging output
    echo "Form submitted. Email: $email, Password: $password<br>";

    // Prepare SQL query to check if user exists
    $sql = "SELECT * FROM admins WHERE email = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("s", $email); // Bind the email to the SQL query
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "User found.<br>";
            $row = $result->fetch_assoc();
            // Verify password
            if (password_verify($password, $row['password'])) {
                echo "Password verified.<br>";
                // Store user data in session
                $_SESSION['admin_id'] = $row['id'];
                $_SESSION['admin_email'] = $row['email'];

                // Redirect to dashboard
                header("Location: admin_dashboard.php");
                exit(); // Ensure the script stops executing after redirection
            } else {
                $error_message = "Invalid email or password.";
                echo $error_message . "<br>";
            }
        } else {
            $error_message = "Invalid email or password.";
            echo $error_message . "<br>";
        }

        // Close statement
        $stmt->close();
    } else {
        $error_message = "Error: " . $conn->error;
        echo $error_message . "<br>";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        .form-container {
            max-width: 400px;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .form-container h2 {
            text-align: center;
        }
        .form-container label {
            display: block;
            margin-top: 10px;
        }
        .form-container input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            margin-top: 20px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 5px;
        }
        .form-footer {
            text-align: center;
            margin-top: 20px;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Admin Login</h2>
        <form action="admin_login.php" method="POST">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <button type="submit">Login</button>
        </form>
        <div class="form-footer">
            <p>New here? <a href="admin_signup.php">Sign Up</a></p>
            <p><a href="forgot_password.php">Forgot Password?</a></p>
        </div>
        <?php if ($error_message): ?>
            <div class="error-message">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
