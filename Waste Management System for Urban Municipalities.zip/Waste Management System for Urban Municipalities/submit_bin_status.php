<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "waste management system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if admin is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if session variable is not set
    exit();
}

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Retrieve location and status from POST data
$location = $_POST['location'];
$status = $_POST['status'];

// Prepare SQL statement using prepared statement to prevent SQL injection
$sql = "INSERT INTO bins_status (id, location, status) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt) {
    // Bind parameters and execute the statement
    $stmt->bind_param("iss", $admin_id, $location, $status);

    if ($stmt->execute()) {
        echo "<script>alert('New record created successfully'); window.location.href='dashboard.php';</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "'); window.location.href='index.html';</script>";
    }

    // Close statement
    $stmt->close();
} else {
    echo "<script>alert('Error preparing statement: " . $conn->error . "'); window.location.href='index.html';</script>";
}

// Close connection
$conn->close();
?>
