<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "waste management system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables for error and success messages
$error_message = "";
$success_message = "";

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $county = $_POST['county'];
    $constituency = $_POST['constituency'];
    $issue = $_POST['issue'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO issues (name, email, phone, county, constituency, issue) VALUES (?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        // Display the error message if prepare failed
        $error_message = "Error preparing statement: " . $conn->error;
    } else {
        $stmt->bind_param("ssssss", $name, $email, $phone, $county, $constituency, $issue);

        // Execute the statement
        if ($stmt->execute()) {
            $success_message = "Your report has been submitted successfully!";
        } else {
            $error_message = "Error executing statement: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }
}

// Close the connection
$conn->close();
?>
