<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "waste management system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$title = $_POST['title'];
$description = $_POST['description'];
$date = $_POST['date'];
$time = $_POST['time'];
$location = $_POST['location'];

$sql = "INSERT INTO events (title, description, date, time, location) VALUES ('$title', '$description', '$date', '$time', '$location')";

if ($conn->query($sql) === TRUE) {
    echo "New event posted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
