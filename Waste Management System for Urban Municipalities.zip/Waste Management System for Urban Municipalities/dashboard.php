<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection parameters
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "waste management system"; // Ensure this matches your database name

// Create connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user data using user_id
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);

if ($stmt) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $username = $row['Fullname'];
        $email = $row['email'];
    } else {
        echo "User not found.";
        exit();
    }

    // Close statement
    $stmt->close();
} else {
    echo "Error: " . $conn->error;
    exit();
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Waste Management Dashboard</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to external CSS file for styling -->
    <style>
        /* External CSS file (styles.css) for more complex styling */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1900px;
            max-height: 1500px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .header {
            background-color: #007bff;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        .sidebar {
            width: 250px;
            background-color: #f8f9fa;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            float: left;
        }

        .sidebar h2 {
            color: #007bff;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            margin: 10px 0;
        }

        .sidebar ul li a {
            color: #007bff;
            text-decoration: none;
            display: block;
        }

        .sidebar ul li a:hover {
            text-decoration: underline;
        }

        .main-content {
            max-width: 290px;
            margin-left: 270px; /* Sidebar width + padding */
            padding: 20px;
        }

        .dashboard-section {
            background-color: #fff;
            margin-bottom: 20px;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }

        .dashboard-section h2 {
            color: #007bff;
            margin-bottom: 10px;
        }

        .dashboard-section p {
            margin-bottom: 8px;
        }

        .profile-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }

        .profile-section h2 {
            color: #007bff;
            margin-bottom: 10px;
        }

        .profile-section p {
            margin-bottom: 8px;
        }

        footer {
            background-color: #007bff;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            clear: both;
        }

        /* Styling for pop-up forms */
        .popup-form {
            display: none;
            position: fixed;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            z-index: 1000;
            max-width: 400px;
            width: 90%;
        }

        .popup-form label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .popup-form input[type="text"],
        .popup-form input[type="email"],
        .popup-form textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        .popup-form button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        }

        .popup-form button:hover {
            background-color: #0056b3;
        }
    </style>
    <script>
        function updateConstituencies() {
            const countySelect = document.getElementById('county');
            const constituencySelect = document.getElementById('constituency');
            const selectedCounty = countySelect.value;

            const constituencies = {
                "Nairobi": [
                    "Westlands", "Dagoretti North", "Dagoretti South", "Lang'ata", "Kibra",
                    "Roysambu", "Kasarani", "Ruaraka", "Embakasi South", "Embakasi North",
                    "Embakasi Central", "Embakasi East", "Embakasi West", "Makadara",
                    "Kamukunji", "Starehe", "Mathare"
                ],
                "Kiambu": [
                    "Gatundu South", "Gatundu North", "Juja", "Thika Town", "Ruiru",
                    "Githunguri", "Kiambu", "Kiambaa", "Kabete", "Kikuyu", "Limuru",
                    "Lari"
                ],
                "Machakos": [
                    "Masinga", "Yatta", "Kangundo", "Matungulu", "Kathiani",
                    "Mavoko", "Machakos Town", "Mwala"
                ]
            };

            // Clear previous options
            constituencySelect.innerHTML = '';

            // Populate new options
            constituencies[selectedCounty].forEach(function (constituency) {
                const option = document.createElement('option');
                option.value = constituency;
                option.textContent = constituency;
                constituencySelect.appendChild(option);
            });
        }

        window.onload = function() {
            updateConstituencies();
        };
    </script>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Waste Management Dashboard</h1>
        </div>
        
        <div class="sidebar">
            <h2>Navigation</h2>
            <ul>
                <li><a href="#">Dashboard</a></li>
                <li><a href="#" onclick="openPopupForm('binsForm')">Bins Status</a></li>
                <li><a href="#" onclick="openPopupForm('serviceRequestForm')">Request Service</a></li>
                <li><a href="#" onclick="openPopupForm('feedbackForm')">Feedback</a></li>
                <li><a href="#">View Schedule</a></li>
                <li><a href="#" onclick="openPopupForm('event registration')">Feedback</a></li>
                <a href="logout.php">Logout</a>
            </ul>
        </div>

        <div class="main-content">
            <div class="dashboard-section">
                <h2>Overview</h2>
                <p>Welcome to your waste management dashboard. Here you can monitor and manage waste collection activities.</p>
            </div>

            <div class="dashboard-section">
                <h2>Bins Status</h2>
                <p>Current status of your waste bin</p>
            </div>

            <div class="dashboard-section">
                <h2>Reports</h2>
                <p>View detailed reports on waste collection efficiency, recycling rates, etc.</p>
            </div>

            <div class="profile-section">
        <h2>User Profile</h2>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($_SESSION['username']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['email']); ?></p>
        <p><strong>Role:</strong> Administrator</p>
        <p><strong>Settings:</strong> <a href="#">Edit Profile</a> | <a href="#">Change Password</a></p>
    </div>
        </div>

        <footer>
            <p>&copy; 2024 Waste Management Dashboard. All rights reserved.</p>
        </footer>
    </div>

    <!-- Pop-up forms -->
    <div id="binsForm" class="popup-form">
        <h2>Bins Status</h2>
        <form action="submit_bin_status.php" method="post">
            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required>
            <label for="status">Status:</label>
            <input type="text" id="status" name="status" required>
            <button type="submit">Submit</button>
        </form>
        <button onclick="closePopupForm('binsForm')">Close</button>
    </div>

    <div id="serviceRequestForm" class="popup-form">
        <h2>Request Service</h2>
        <form action="submit_service_request.php" method="post">
            <label for="county">County:</label>
            <select id="county" name="county" onchange="updateConstituencies()">
                <option value="Nairobi">Nairobi</option>
                <option value="Kiambu">Kiambu</option>
                <option value="Machakos">Machakos</option>
            </select>
            <br>
            <label for="constituency">Constituency:</label>
            <select id="constituency" name="constituency">
                <!-- Options will be populated by JavaScript -->
            </select>
            <br>
            <label for="phone">Phone Number:</label>
            <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" pattern="[0-9]{10}" required>
            <br>
            <label>Services:</label><br>
            <input type="checkbox" id="residential" name="service[]" value="Residential Waste Collection">
            <label for="residential">Residential Waste Collection</label><br>
            <input type="checkbox" id="commercial" name="service[]" value="Commercial Waste Collection">
            <label for="commercial">Commercial Waste Collection</label><br>
            <input type="checkbox" id="recycling" name="service[]" value="Recycling Services">
            <label for="recycling">Recycling Services</label><br>
            <input type="checkbox" id="hazardous" name="service[]" value="Hazardous Waste Disposal">
            <label for="hazardous">Hazardous Waste Disposal</label><br>
            <input type="checkbox" id="composting" name="service[]" value="Organic Waste Composting">
            <label for="composting">Organic Waste Composting</label><br>
            <input type="checkbox" id="bulk" name="service[]" value="Bulk Waste Pickup">
            <label for="bulk">Bulk Waste Pickup</label><br>
            <br>
            <input type="submit" value="Submit">
        </form>
        <button onclick="closePopupForm('serviceRequestForm')">Close</button>
    </div>

    <div id="feedbackForm" class="popup-form">
    <h2>Rate Our Service</h2>
    <form action="submit_rating.php" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" disabled>
        
        <label for="rating">Rating:</label>
        <div class="emojis">
            <input type="radio" id="emoji5" name="rating" value="5" /><label for="emoji5" title="Excellent">&#128525;</label>
            <input type="radio" id="emoji4" name="rating" value="4" /><label for="emoji4" title="Good">&#128512;</label>
            <input type="radio" id="emoji3" name="rating" value="3" /><label for="emoji3" title="Average">&#128528;</label>
            <input type="radio" id="emoji2" name="rating" value="2" /><label for="emoji2" title="Poor">&#128543;</label>
            <input type="radio" id="emoji1" name="rating" value="1" /><label for="emoji1" title="Terrible">&#128545;</label>
        </div>
        
        <label for="feedback">Feedback:</label>
        <textarea id="feedback" name="feedback" rows="4" placeholder="Leave your feedback here..."></textarea>
        
        <button type="submit">Submit</button>
    </form>
    <button onclick="closePopupForm('feedbackForm')">Close</button>
</div>
<!-- Add the following section to your admin dashboard -->
    <script>
        function openPopupForm(formId) {
            document.getElementById(formId).style.display = "block";
        }

        function closePopupForm(formId) {
            document.getElementById(formId).style.display = "none";
        }
    </script>
</body>
</html>
