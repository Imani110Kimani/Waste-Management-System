<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "waste management system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user ID from session
$user_id = $_SESSION['user_id'];

// Retrieve form data
$county = $_POST['county'];
$constituency = $_POST['constituency'];
$phone = $_POST['phone'];
$services = implode(", ", $_POST['service']);

// Prepare SQL statement using prepared statement to prevent SQL injection
$sql = "INSERT INTO service_requests (id, county, constituency, phone, services) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt) {
    // Bind parameters and execute the statement
    $stmt->bind_param("issss", $_id, $county, $constituency, $phone, $services);

    if ($stmt->execute()) {
        echo "<script>alert('New record created successfully'); window.location.href='dashboard.php';</script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "'); window.location.href='index.html';</script>";
    }

    // Close statement
    $stmt->close();
} else {
    echo "<script>alert('Error preparing statement: " . $conn->error . "'); window.location.href='index.html';</script>";
}

// Close connection
$conn->close();
?>
