<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "waste management system"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to count users
$sql = "SELECT COUNT(*) AS user_count FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetch result row (there should be only one row)
    $row = $result->fetch_assoc();
    $user_count = $row['user_count'];
    echo "Number of users: " . $user_count;
} else {
    echo "0 users found.";
}

// Close connection
$conn->close();
?>
