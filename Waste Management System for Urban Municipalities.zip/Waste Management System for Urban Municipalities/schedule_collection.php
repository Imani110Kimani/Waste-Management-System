<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "waste management system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$location = $_POST['location'];
$date = $_POST['date'];
$time = $_POST['time'];
$frequency = $_POST['frequency'];

$sql = "INSERT INTO collection_schedule (location, date, time, frequency) VALUES ('$location', '$date', '$time', '$frequency')";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('New collection schedule created successfully'); window.location.href='index.php';</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
