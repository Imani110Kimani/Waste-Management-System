<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['admin_id'])) {
    // Redirect to login page if not logged in
    header("Location: admin_login.php");
    exit();
}

// Database connection details
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "waste management system";

// Create the connection
$conn = new mysqli($servername, $db_username, $db_password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['schedule_service'])) {
    // Get the form data
    $service_date = $_POST['service_date'];
    $service_time = $_POST['service_time'];
    $location = $_POST['location'];
    $admin_id = $_SESSION['admin_id']; // Get the admin ID from the session

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO schedule_services (service_date, service_time, location, id) VALUES (?, ?, ?, ?)");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("sssi", $service_date, $service_time, $location, $id);

   // Redirect to dashboard
   header("Location: admin_dashboard.php");
   exit();
    } else {
        echo "<script>alert('Error scheduling service: " . $stmt->error . "');</script>";
    }

    // Close the statement
    $stmt->close();


// Close the connection
$conn->close();
?>