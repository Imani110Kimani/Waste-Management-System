<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Waste Management System</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            height: 100%; /* Ensure the body takes the full height for scrolling */
            overflow-y: scroll; /* Enable vertical scrolling */
            position: relative;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            position: relative;
            z-index: 2;
            background: rgba(255, 255, 255, 0.8); /* Add a semi-transparent background for readability */
        }

        /* Header Styles */
        header {
            background-color: rgba(0, 123, 255, 0.8);
            color: #fff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
            z-index: 3;
        }
        .logo img {
            height: 50px; /* Adjust the height as needed */
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        nav ul li {
            margin-right: 20px;
        }
        nav ul li:last-child {
            margin-right: 0;
        }
        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            transition: color 0.3s;
        }
        nav ul li a:hover {
            color: #ffc107;
        }

        /* Dropdown Styles */
        .dropdown {
            position: relative;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            z-index: 1;
            border-radius: 0 0 4px 4px;
        }
        .dropdown-content a {
            color: #333;
            padding: 12px 16px;
            display: block;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }

        .text {
            width: 100%;
            text-align: center;
            font-size: 1.5em;
            margin-top: 20px;
        }

        /* Footer Styles */
        footer {
            background-color: #333;
            color: #fff;
            padding: 20px 20px;
            text-align: center;
            position: absolute;
            z-index: 3;
        }
        footer ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        footer ul li {
            display: inline-block;
            margin-right: 20px;
        }
        footer ul li:last-child {
            margin-right: 0;
        }
        footer ul li a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            transition: color 0.3s;
        }
        footer ul li a:hover {
            color: #ffc107;
        }

        /* Video Background Styles */
        .video-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <video autoplay muted loop class="video-background">
        <source src="images/Smart Waste Management Monitoring System _ Smart City Solutions (online-video-cutter.com).mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>

<header>
    <a href="index.html" class="logo"><img src="images/logo.png" alt="Waste Management System"></a>
    <div class="text">Welcome to Waste Management System</div>
    <nav>
        <ul>
            <li class="dropdown">
                <a href="Who_we_are.html" class="dropbtn">Who we are</a>
                <div class="dropdown-content">
                    <a href="#">About Us</a>
                    <a href="#">Our Team</a>
                    <a href="#">Mission & Vision</a>
                </div>
            </li>
            <li class="dropdown">
                <a href="What_we_do.html" class="dropbtn">What we do</a>
                <div class="dropdown-content">
                    <a href="#">Services</a>
                    <a href="#">Projects</a>
                    <a href="#">Testimonials</a>
                </div>
            </li>
            <li><a href="Registration frm.html">Sign Up</a></li>
            <li><a href="login.php">Sign In</a></li>
            <li><a href="admin_login.php">Admin Login</a></li>
        </ul>
    </nav>
</header>

<div class="container">
    <!-- Add your content here -->
</div>

<footer>
    <h2>Quick Links</h2>
    <ul>
        <li><a href="#">Contact Us</a></li>
        <li><a href="#">Careers</a></li>
        <li><a href="#">Privacy policy</a></li>
    </ul>
</footer>
</body>
</html>
