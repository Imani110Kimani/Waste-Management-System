<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "waste management system"; // Corrected database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch users from database
$sql = "SELECT id, Fullname, email FROM users";
$result = $conn->query($sql);

$users = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
} else {
    echo "0 results";
}

$conn->close();

// Function to generate HTML for user table
function generateUserTable($users) {
    $html = '';
    foreach ($users as $user) {
        $html .= '
            <tr>
                <td>' . $user['id'] . '</td>
                <td>' . $user['Fullname'] . '</td>
                <td>' . $user['email'] . '</td>
                <td><button onclick="editUser(' . $user['id'] . ')">Edit</button></td>
            </tr>
        ';
    }
    return $html;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        td button {
            padding: 5px 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        td button:hover {
            background-color: #45a049;
        }
        .btn-back {
            margin: 20px;
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
        }
        .btn-back:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <h2>User Management</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php echo generateUserTable($users); ?>
        </tbody>
    </table>

    <a href="admin_dashboard.php" class="btn-back">Back to Dashboard</a>

    <script>
        function editUser(userId) {
            // Redirect to edit page or perform edit action
           // alert('Editing user with ID ' + userId);
            window.location.href = 'edit_user.php?id=' + userId;
        }
    </script>
</body>
</html>
