<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "waste management system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user ID from session
$user_id = $_SESSION['user_id'];

// Prepare SQL statement to retrieve service requests
$sql = "SELECT * FROM service_requests WHERE id = ?";
$stmt = $conn->prepare($sql);

if ($stmt) {
    // Bind parameter and execute statement
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // Get result
    $result = $stmt->get_result();

    // Check if there are rows returned
    if ($result->num_rows > 0) {
        echo '<div class="content">';
        echo '<h2>Service Requests</h2>';
        echo '<table>';
        echo '<thead>';
        echo '<tr>';
        echo '<th>ID</th>';
        echo '<th>County</th>';
        echo '<th>Constituency</th>';
        echo '<th>Phone</th>';
        echo '<th>Services</th>';
        echo '<th>Action</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row['id'] . '</td>';
            echo '<td>' . $row['county'] . '</td>';
            echo '<td>' . $row['constituency'] . '</td>';
            echo '<td>' . $row['phone'] . '</td>';
            echo '<td>' . $row['services'] . '</td>';
            echo '<td><a href="#" onclick="openPopup(' . $row['request_id'] . '); return false;">Process</a></td>'; // Open popup onclick
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
        echo '</div>';
    } else {
        echo '<p>No service requests found.</p>';
    }

    // Close statement
    $stmt->close();
} else {
    echo '<p>Error retrieving service requests.</p>';
}

// Close connection
$conn->close();
?>

<script>
function openPopup(requestId) {
    // Open popup window for processing request
    var popupUrl = 'process_request.php?id=' + requestId;
    var popupWindow = window.open(popupUrl, '_blank', 'width=600,height=400');
    if (!popupWindow) {
        alert('Popup blocked! Please allow popups for this site.');
    }
}
</script>
